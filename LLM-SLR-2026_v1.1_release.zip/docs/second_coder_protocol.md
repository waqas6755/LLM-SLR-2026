# TODO-1 protocol: independent second coding and Cohen's kappa

Version 1.0, written 12 October 2026, before any second coding. Status: **materials ready; no second coder has coded anything yet.**

## 1. Population and sample size

- **Population:** all 304 studies that passed title/abstract screening (`analysis/coded_corpus.csv`; matches the 304 "Included" rows of `analysis/screening_log_all.csv`). You approved using all 304 so that the scope decision (in or out of persistent poisoning) is itself tested.
- **Sample size:** n = ⌈0.20 × 304⌉ = ⌈60.8⌉ = **61**. Rounding up guarantees at least 20%.

## 2. Sampling

- Stratified by the first coder's Scope label, with proportional allocation. Integer stratum sizes come from the largest-remainder method (quotas PA 23.08, TR 20.87, NP 15.45, AN 0.60, SCX 0.60, UND 0.40).
- **Allocation:** PA 23, TR 21, NP 15, AN 1, SCX 1, UND 0, for a total of 61.
- Simple random sampling without replacement inside each stratum, using numpy `default_rng(20261012)`. The seed was fixed before the draw. Sheet order is randomly permuted with the same generator.
- Proportional allocation keeps the sample close to self-weighting, so unweighted κ approximates the corpus-level value. The cost is that the sparse classes (SCX, AN, UND) get 0 or 1 study each, so their agreement cannot be estimated.
- Script: `scripts/draw_sample.py`. Records: `coordinator_only/sample_manifest.csv` and `coordinator_only/freeze.json`, which holds the SHA-256 of the first-coder sheet at draw time (`44472cdc…`).

## 3. Blinding

- The second coder receives **only** the `to_second_coder/` folder: the blinded sheet, the codebook and the instructions.
- The sheet has no first-coder fields and no search category, and its rows are shuffled.
- **Do not send the project zip or the Overleaf project.** They contain `analysis/coded_corpus.csv` and the manuscript's results.
- The codebook's worked examples all come from studies outside the sample.
- `compute_agreement.py` refuses to run if the first-coder sheet has changed since the draw.

## 4. Coding basis

Both coders use the title and abstract only, so the comparison is like for like. The first coder was AI-assisted, and the second coder is asked not to use AI tools; the result therefore measures agreement between an AI-assisted coder and an unassisted human. This is reported as such.

## 5. Analysis (pre-specified)

Run `python3 scripts/compute_agreement.py returned/<file>` once, on the sheet as returned and before any discussion.

| Variable | Population | Role |
|---|---|---|
| Scope, 6 categories | 61 sampled | Primary |
| Scope, PA vs not PA | 61 sampled | Primary (the decision that defines the 115) |
| Mechanism, Mechanism_Ambiguous, Stage, Persistence | Studies both coders put in PA | Secondary, exploratory |

- **Statistics:**
  - n and observed agreement p_o;
  - Cohen's κ [1], with an asymptotic 95% CI [2] and a percentile bootstrap 95% CI (2,000 resamples, seed 20261013);
  - Gwet's AC1 [3];
  - PABAK for the binary variable [4];
  - per-category specific agreement and the full contingency table.
- **Missing data:** a blank cell is missing, not a category. Missing rows are dropped from that variable and the count is reported; no imputation. UND and NA are valid codes.
- **Small n:** for a secondary variable with n < 10, report counts and p_o only.
- **Implementation check:** κ and its SE match `statsmodels.cohens_kappa` to 1e-9 on test tables (`scripts/test_compute_agreement.py`). The tests use textbook tables, not project data.

## 6. Interpretation and decision rule (fixed now)

- Report the numbers; descriptive labels such as Landis and Koch's [5] are given only as convention.
- **Decision rule:** if κ for binary scope is below 0.60, or its bootstrap lower bound is below 0.40, the scope rules are treated as not yet reliable. In that case the codebook is revised (new version, change log) and a fresh, non-overlapping sample of 61 is double-coded before the paper reports scope-based counts as reliable.

## 7. Adjudication (after κ is computed and saved)

1. Freeze the returned sheet (its SHA-256 is stored in `agreement_results.json`) and the agreement report.
2. The two coders meet. For each disagreement, each states the codebook rule they applied.
3. Agree a final code. If no agreement is reached, a third person (suggested: the supervisor) decides.
4. Log every decision in `adjudication_log.csv` (copy of `adjudication_log_TEMPLATE.csv`).
5. If a disagreement exposes an unclear rule, revise the codebook (version 1.1, change log), re-apply the revised rule to **all 304** first-coder records, and log every changed code.
6. Recompute all reported counts by script from the adjudicated sheet. Report agreement **before** adjudication and counts **after** it.

Issues already noticed in the frozen first-coder sheet (for example P097) are listed in `coordinator_only/first_coder_issues_log.md` and are handled at step 5 or in TODO-2. They are not changed before κ is computed.

## 8. Known limitations

- **Prevalence:** PA, TR and NP cover 59 of 61 rows. κ can be low even when agreement is high if one category dominates a binary split, which is why AC1 and PABAK are also reported.
- **Sparse categories:** SCX and AN have one sampled study each and UND has none, so agreement on them cannot be estimated.
- **Secondary variables:** they are conditional on both coders choosing PA (about 23 studies at most). The sparse codes D-GL, PT and B will have very small cells.
- **Assumptions of κ:** nominal categories, the same category set for both coders, and independent coders. Coders who differ in their marginal tendencies (bias) also lower κ; compare the marginal totals in the contingency table.
- **Scope of the check:** two coders, abstracts only. The check says nothing about full-text accuracy, which is TODO-2.

## 9. Status

| Step | Status |
|---|---|
| Codebook v1.0 | Done (`docs/codebook.md`) |
| Sample drawn and frozen | Done (61 studies) |
| Blinded sheet, instructions | Done (`to_second_coder/`) |
| Agreement script, tests | Done; tested on textbook tables only |
| Second coder identified | **Pending: your action** |
| Second coding | **Pending** |
| κ computed | **Pending**; no agreement value exists |
| Adjudication | **Pending** |

## References

[1] J. Cohen, "A coefficient of agreement for nominal scales," *Educational and Psychological Measurement*, vol. 20, no. 1, pp. 37–46, 1960.
[2] J. L. Fleiss, J. Cohen, and B. S. Everitt, "Large sample standard errors of kappa and weighted kappa," *Psychological Bulletin*, vol. 72, no. 5, pp. 323–327, 1969.
[3] K. L. Gwet, "Computing inter-rater reliability and its variance in the presence of high agreement," *British Journal of Mathematical and Statistical Psychology*, vol. 61, no. 1, pp. 29–48, 2008.
[4] T. Byrt, J. Bishop, and J. B. Carlin, "Bias, prevalence and kappa," *Journal of Clinical Epidemiology*, vol. 46, no. 5, pp. 423–429, 1993.
[5] J. R. Landis and G. G. Koch, "The measurement of observer agreement for categorical data," *Biometrics*, vol. 33, no. 1, pp. 159–174, 1977.
