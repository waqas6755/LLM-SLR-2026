# THREAT-LLM coding codebook, version 1.0 (12 October 2026)

This codebook writes down the rules the first coder applied, so that a second coder can apply them independently. It mirrors Algorithm 1 and Section IV of the manuscript. Any change after second coding starts must be logged in Section 8 with a new version number.

## 1. Unit and basis of coding

- **Unit:** one study (one row). Code the attack or threat that the abstract presents as the paper's main contribution. If the paper proposes several attacks, code the first or headline one.
- **Basis:** the **title and abstract only**, exactly as given in the sheet. Do not open the full text, search the web for the paper, or use what you remember about it. The first coder worked from the same information, and agreement is measured on that basis.
- **Code what the abstract says, not what you think the paper probably did.** If the abstract does not let you decide, use the "cannot determine" code for that variable.

## 2. Variables at a glance

| Column | Values | When to fill |
|---|---|---|
| Scope | PA, NP, TR, SCX, AN, UND | Always |
| Scope_Confidence | High, Medium, Low | Always |
| Scope_Evidence | Up to 25 words quoted from the title or abstract | Always |
| Mechanism | D-DL, D-ML, D-GL, D-DL;D-ML | Only if Scope = PA; otherwise NA |
| Mechanism_Ambiguous | Yes, No | Only if Scope = PA; otherwise NA |
| Stage | PT, FT, AL, DI, FT;AL, UND | Only if Scope = PA; otherwise NA |
| Persistence | S, P, B, M, U | Only if Scope = PA; otherwise NA |
| Persistence_Evidence | Up to 25 words quoted | Only if Persistence is S, P, B or M |
| Notes | Free text | Optional; use it for any doubt |
| AI_tool_used | No, Yes | Always (see the instructions) |

## 3. Scope: the decision order

Apply the questions **in this order** and stop at the first "yes". The order matters: a study that matches an earlier rule takes that code even if a later rule also fits.

| Step | Question | If yes |
|---|---|---|
| S1 | Does the attack only change the **input at inference time** (prompt, query, image, suffix, injected instruction), with **no change** to any model weight, adapter or training signal? | **TR** (transient) |
| S2 | Does the attacker write only to **external state read at inference time**: a retrieval corpus or RAG store, agent memory, a tool or plugin description, or a system prompt? Model weights stay unchanged. | **NP** (non-parametric store or context) |
| S3 | Is the payload **executable code hidden in a serialised model file** (for example pickle), with no change to learned behaviour? | **SCX** (artifact code execution) |
| S4 | Does the study **not carry out or benchmark an attack**, but analyse already-poisoned models, incidents, advisories or ecosystems (for example interpretability of a backdoored model, or a measurement study)? | **AN** (analysis) |
| S5 | Does the attack change a **model artifact**: weights, an adapter, an edited layer, or a checkpoint built from them, through training data, the training procedure, or direct modification, so that the change stays in the artifact? | **PA** (persistent artifact poisoning) |
| (none) | The abstract does not give enough information to answer S1 to S5. | **UND** |

### Boundary rules

- **Weights changed means PA.** If any model parameter or adapter changes, code PA even when the trigger is later delivered through a prompt. A backdoor that makes prompt injection succeed is PA. A jailbreak backdoor planted through poisoned preference data is PA.
- **Benchmarks** that implement and compare poisoning attacks are coded by the attacks they run (PA if those attacks change weights). They are not AN.
- **Poisoned demonstrations or few-shot examples** supplied only in the prompt are TR. If the attacker fine-tunes the model so that it misbehaves under certain demonstrations, the code is PA.
- **Federated learning:** malicious client updates change the global model, so the code is PA (mechanism D-GL).
- **Multimodal models** follow the same rules: a poisoned image at inference is TR; training on poisoned image-text pairs is PA.
- **Defence papers** that also introduce a new attack: code the attack. Defence-only papers with no attack: AN.

## 4. Mechanism (only if PA)

Record what the attacker controls. Check D-GL first, then D-ML, then D-DL, and assign the first one that fits.

| Code | Definition | Typical wording |
|---|---|---|
| D-GL | The attacker controls the **optimisation procedure**: loss, gradients, client updates, training code or platform | "malicious clients", "adversarial RLHF platform", "modified training loop" |
| D-ML | The attacker **delivers modified parameters or a learned artifact**, including a model they trained and published | "backdoored checkpoint on a model hub", "malicious LoRA", "model editing", "merge", "backdoored teacher" |
| D-DL | The attacker controls **only data the victim trains on** | "poisoned instruction data", "poisoned preference pairs", "web-scale data poisoning" |
| D-DL;D-ML | The abstract explicitly presents **both** routes as part of the attack | |

**Mechanism_Ambiguous = Yes** when the abstract does not say who trains the poisoned model. For example, "we poison model X" can mean the attacker supplies data or the attacker supplies the trained model. Still give your best-guess mechanism in the Mechanism column.

## 5. Stage (only if PA)

The **earliest** lifecycle stage at which the payload enters the artifact.

| Code | Stage |
|---|---|
| PT | Pretraining or continued pretraining on large unlabelled corpora |
| FT | Supervised instruction tuning or task fine-tuning (including agent fine-tuning) |
| AL | Preference alignment: RLHF, reward models, DPO, preference data |
| DI | Post-training distribution: model editing, adapters or LoRA, merging, distillation, a published checkpoint |
| FT;AL | The abstract describes injection at both FT and AL |
| UND | The abstract does not say |

## 6. Persistence (only if PA)

Code only what the abstract reports about attack success **after a later transformation** τ (clean or continued fine-tuning, safety training or re-alignment, merging, distillation, quantisation, a named defence that retrains the model).

| Code | Meaning |
|---|---|
| S | The attack survives τ |
| P | The attack partly survives τ (reported as reduced but still present) |
| B | The study's baseline attacks degrade under τ while its proposed attack survives |
| M | τ mitigates or removes the attack |
| U | The abstract reports no result after any later transformation. **U does not mean the attack fails to persist.** |

Inference-time defences that do not retrain the model (input filters, detectors) are not a transformation τ.

## 7. Worked examples

All examples are studies **outside** the second-coder sample. They show how the rules are applied; they are not answers for sampled studies.

| ID | Title (short) | Scope | Mech. | Ambig. | Stage | Pers. | Why |
|---|---|---|---|---|---|---|---|
| P007 | Poisoning Language Models During Instruction Tuning | PA | D-DL | No | FT | U | Attacker contributes poisoned examples to instruction data; no post-τ result in the abstract |
| P014 | BadEdit: backdooring LLMs by model editing | PA | D-ML | No | DI | S | Attacker edits weights directly; abstract reports robustness to subsequent fine-tuning |
| P238 | LoRATK: LoRA once, backdoor everywhere | PA | D-ML | No | DI | S | Malicious adapter shared and merged by users |
| P056 | Model poisoning attacks on federated LLMs | PA | D-GL | No | FT | U | Malicious client updates during federated fine-tuning |
| P083 | AdvBDGen: fuzzy backdoor generator against LLM alignment | PA | D-DL | No | AL | S | Poisoned preference data |
| P010 | Stealthy and persistent unalignment via backdoor injections | PA | D-DL | **Yes** | FT | B | Abstract does not make clear whether the attacker supplies data or the fine-tuned model |
| P113 | BadRAG | NP | NA | NA | NA | NA | Poisoned passages in the retrieval corpus; weights unchanged (S2) |
| P110 | Automatic and universal prompt injection attacks | TR | NA | NA | NA | NA | Only the input changes (S1) |
| P251 | Pickle-based model supply chain poisoning | SCX | NA | NA | NA | NA | Malicious code in the serialised model file (S3) |
| P046 | Mechanistic exploration of backdoored LLM attention | AN | NA | NA | NA | NA | Analyses backdoored models; proposes no attack (S4) |

## 8. Change log

| Version | Date | Change | Reason | Studies affected |
|---|---|---|---|---|
| 1.0 | 12 Oct 2026 | First written version of the rules used by the first coder | Needed for independent second coding (TODO-1) | none |
