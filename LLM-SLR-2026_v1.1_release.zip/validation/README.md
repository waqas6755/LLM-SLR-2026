# Validation scripts

`compute_agreement.py` computes inter-rater agreement once both coding sheets exist. It reads the first-coder labels and the frozen sample manifest, which are **not** in this release (held back to keep the second coding blind), so it runs inside the full project folder, not from this release alone. `test_compute_agreement.py` runs on its own and checks the statistics against hand-computed tables and, if installed, `statsmodels`.
