"""TODO-1 step 3: inter-rater agreement between the first coder and the independent second coder.

Run ONLY after the second coder has returned a completed sheet and BEFORE any adjudication.
It refuses to run if the first-coder sheet changed since the sample was drawn (hash in freeze.json).

Usage:
  python3 compute_agreement.py ../returned/second_coder_sheet_completed.xlsx   (or .csv)

Variables analysed (nominal, unweighted):
  Primary  : Scope, 6 categories (PA, NP, TR, SCX, AN, UND)          all sampled studies
  Primary  : Scope, binary (PA vs not PA)                            all sampled studies
  Secondary: Mechanism, Mechanism_Ambiguous, Stage, Persistence                          studies BOTH coders put in PA
Statistics: n, observed agreement p_o, Cohen's kappa with asymptotic 95% CI (Fleiss, Cohen & Everitt 1969)
            and percentile bootstrap 95% CI (2,000 resamples, fixed seed), Gwet's AC1, PABAK (binary only),
            per-category agreement, full contingency table.
Missing data: a blank second-coder cell is MISSING (not a category). Missing rows are dropped from that
            variable's analysis and counted in the report. "UND" (cannot determine) is a valid category.
Outputs: ../agreement_report.md and ../agreement_results.json
"""
import csv, hashlib, json, math, os, sys
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, "..", "..", ".."))
BASE = os.path.join(HERE, "..")
BOOT_SEED, BOOT_B = 20261013, 2000

SCOPE_CODE = {
    "Persistent artifact poisoning (data/parameters/adapters/pipeline)": "PA",
    "Non-parametric store/context poisoning (deployment)": "NP",
    "Excluded-transient (inference-time input manipulation)": "TR",
    "Supply-chain code execution via model artifact (not behavioural poisoning)": "SCX",
    "Analysis/non-adversarial (no new attack)": "AN",
    "Unresolved": "UND",
}
STAGE_CODE = {
    "Pretraining": "PT", "SFT/instruction/task fine-tuning": "FT", "Preference/alignment": "AL",
    "Post-training distribution (weights/adapters/editing/merging)": "DI",
    "SFT/instruction/task fine-tuning;Preference/alignment": "FT;AL", "": "NA",
}

# ---------------------------------------------------------------- statistics
def table(a, b, cats):
    idx = {c: i for i, c in enumerate(cats)}
    m = np.zeros((len(cats), len(cats)), dtype=int)
    for x, y in zip(a, b):
        m[idx[x], idx[y]] += 1
    return m

def kappa_from_table(m):
    n = m.sum()
    if n == 0:
        return dict(n=0)
    p = m / n
    po = np.trace(p)
    r, c = p.sum(1), p.sum(0)
    pe = float((r * c).sum())
    k = (po - pe) / (1 - pe) if pe < 1 else float("nan")
    # asymptotic SE for kappa under the alternative (Fleiss, Cohen & Everitt, 1969)
    if pe < 1:
        q = len(m)
        t1 = sum(p[i, i] * ((1 - pe) - (r[i] + c[i]) * (1 - po)) ** 2 for i in range(q))
        t2 = (1 - po) ** 2 * sum(p[i, j] * (c[i] + r[j]) ** 2 for i in range(q) for j in range(q) if i != j)
        t3 = (po * pe - 2 * pe + po) ** 2
        var = (t1 + t2 - t3) / (n * (1 - pe) ** 4)
        se = math.sqrt(max(var, 0.0))
    else:
        se = float("nan")
    # Gwet's AC1
    q = len(m)
    pi = (r + c) / 2
    pe_ac1 = float((pi * (1 - pi)).sum() / (q - 1)) if q > 1 else float("nan")
    ac1 = (po - pe_ac1) / (1 - pe_ac1) if q > 1 and pe_ac1 < 1 else float("nan")
    out = dict(n=int(n), p_o=float(po), p_e=pe, kappa=float(k), kappa_se=se,
               kappa_ci_asymptotic=[float(k - 1.96 * se), float(k + 1.96 * se)] if not math.isnan(se) else None,
               gwet_ac1=float(ac1))
    if q == 2:
        out["pabak"] = float(2 * po - 1)
    return out

def bootstrap_ci(a, b, cats, B=BOOT_B, seed=BOOT_SEED):
    rng = np.random.default_rng(seed)
    a, b = np.array(a), np.array(b)
    ks = []
    for _ in range(B):
        i = rng.integers(0, len(a), len(a))
        k = kappa_from_table(table(a[i], b[i], cats))["kappa"]
        if not math.isnan(k):
            ks.append(k)
    if len(ks) < 0.9 * B:
        return None
    return [float(np.percentile(ks, 2.5)), float(np.percentile(ks, 97.5))]

def per_category(m, cats):
    res = {}
    for i, c in enumerate(cats):
        a, b = m[i, :].sum(), m[:, i].sum()
        res[c] = dict(first=int(a), second=int(b), both=int(m[i, i]),
                      specific_agreement=(2 * m[i, i] / (a + b)) if a + b else None)
    return res

def analyse(name, a, b, cats, missing):
    m = table(a, b, cats)
    s = kappa_from_table(m)
    s.update(variable=name, categories=cats, contingency=m.tolist(), missing_dropped=missing,
             per_category=per_category(m, cats))
    if s.get("n", 0) >= 10:
        s["kappa_ci_bootstrap"] = bootstrap_ci(a, b, cats)
    else:
        s["note"] = "n < 10: report counts and p_o only; kappa not interpretable"
    empty = [c for c, v in s["per_category"].items() if v["first"] + v["second"] == 0]
    s["unused_categories"] = empty
    return s

# ---------------------------------------------------------------- io
def sha256(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()

def read_second(path):
    if path.lower().endswith(".xlsx"):
        from openpyxl import load_workbook
        ws = load_workbook(path, read_only=True, data_only=True)["Coding"]
        rows = list(ws.iter_rows(values_only=True))
        head = [str(h) for h in rows[0]]
        return [{h: ("" if v is None else str(v).strip()) for h, v in zip(head, r)} for r in rows[1:] if any(r)]
    return [{k: (v or "").strip() for k, v in r.items()} for r in csv.DictReader(open(path, encoding="utf-8-sig"))]

def main(path):
    freeze = json.load(open(os.path.join(BASE, "coordinator_only", "freeze.json")))
    coded_path = os.path.join(ROOT, freeze["first_coder_sheet"])
    if sha256(coded_path) != freeze["first_coder_sha256"]:
        sys.exit("STOP: the first-coder sheet changed after the sample was drawn. Agreement must use the frozen labels.")
    manifest = list(csv.DictReader(open(os.path.join(BASE, "coordinator_only", "sample_manifest.csv"), encoding="utf-8-sig")))
    first = {r["ID"]: r for r in csv.DictReader(open(coded_path, encoding="utf-8-sig"))}
    second = {r["ID"]: r for r in read_second(path)}
    ids = [r["ID"] for r in manifest]
    absent = [i for i in ids if i not in second]
    if absent:
        sys.exit(f"STOP: {len(absent)} sampled IDs missing from the returned sheet: {absent[:10]}")

    res = {"freeze": freeze, "second_coder_file": os.path.basename(path), "second_coder_sha256": sha256(path),
           "n_sampled": len(ids), "ai_tool_used_yes": sum(second[i].get("AI_tool_used", "").lower() == "yes" for i in ids)}
    scope_cats = ["PA", "NP", "TR", "SCX", "AN", "UND"]
    a, b, miss = [], [], []
    for i in ids:
        s = second[i]["Scope"].upper()
        if not s:
            miss.append(i); continue
        if s not in scope_cats:
            sys.exit(f"STOP: invalid Scope '{s}' for {i}")
        a.append(SCOPE_CODE[first[i]["Scope"]]); b.append(s)
    res["scope6"] = analyse("Scope (6 categories)", a, b, scope_cats, miss)
    res["scope2"] = analyse("Scope (PA vs not PA)", ["PA" if x == "PA" else "not PA" for x in a],
                            ["PA" if x == "PA" else "not PA" for x in b], ["PA", "not PA"], miss)
    both = [i for i in ids if SCOPE_CODE[first[i]["Scope"]] == "PA" and second[i]["Scope"].upper() == "PA"]
    res["n_both_PA"] = len(both)
    for var, fget, cats in [
        ("Mechanism", lambda r: r["Mechanism"] or "NA", ["D-DL", "D-ML", "D-GL", "D-DL;D-ML", "NA"]),
        ("Mechanism_Ambiguous", lambda r: "YES" if r["MechanismFlag"] == "amb" else "NO", ["YES", "NO"]),
        ("Stage", lambda r: STAGE_CODE.get(r["InjectionStage"], "UND"), ["PT", "FT", "AL", "DI", "FT;AL", "UND", "NA"]),
        ("Persistence", lambda r: r["PersistenceOutcome"] or "U", ["S", "P", "B", "M", "U", "NA"]),
    ]:
        a, b, miss = [], [], []
        for i in both:
            s = second[i][var].upper().replace("D-DL;D-ML", "D-DL;D-ML")
            if not s:
                miss.append(i); continue
            if s not in [c.upper() for c in cats]:
                sys.exit(f"STOP: invalid {var} '{s}' for {i}")
            a.append(fget(first[i]).upper()); b.append(s)
        res[var.lower()] = analyse(var + " (both coders PA)", a, b, [c.upper() for c in cats], miss)
    json.dump(res, open(os.path.join(BASE, "agreement_results.json"), "w"), indent=1)
    write_report(res)
    print("Wrote agreement_report.md and agreement_results.json")

def fmt(x, d=3):
    return "n/a" if x is None or (isinstance(x, float) and math.isnan(x)) else f"{x:.{d}f}"

def write_report(res):
    L = ["# Inter-rater agreement (pre-adjudication)", "",
         f"Second-coder file: `{res['second_coder_file']}` (SHA-256 {res['second_coder_sha256'][:16]}...)",
         f"First-coder sheet frozen at draw time: SHA-256 {res['freeze']['first_coder_sha256'][:16]}... (verified unchanged)",
         f"Sample: {res['n_sampled']} of {res['freeze']['N']} studies, seed {res['freeze']['seed']}. "
         f"Rows where the second coder reported AI-tool use: {res['ai_tool_used_yes']}.", ""]
    for key in ["scope6", "scope2", "mechanism", "mechanism_ambiguous", "stage", "persistence"]:
        s = res[key]
        L += [f"## {s['variable']}", "",
              f"n = {s.get('n', 0)}; dropped as missing = {len(s['missing_dropped'])}"]
        if s.get("n", 0):
            L += [f"Observed agreement p_o = {fmt(s['p_o'])}; chance agreement p_e = {fmt(s['p_e'])}",
                  f"Cohen's kappa = {fmt(s['kappa'])} (asymptotic 95% CI {fmt((s['kappa_ci_asymptotic'] or [None])[0])} to {fmt((s['kappa_ci_asymptotic'] or [None, None])[1])}; "
                  f"bootstrap 95% CI {fmt((s.get('kappa_ci_bootstrap') or [None])[0])} to {fmt((s.get('kappa_ci_bootstrap') or [None, None])[1])})",
                  f"Gwet's AC1 = {fmt(s['gwet_ac1'])}" + (f"; PABAK = {fmt(s['pabak'])}" if "pabak" in s else "")]
        if s.get("note"):
            L.append(f"Note: {s['note']}")
        if s["unused_categories"]:
            L.append(f"Categories used by neither coder (shown, not informative): {', '.join(s['unused_categories'])}")
        cats = s["categories"]
        L += ["", "| first \\ second | " + " | ".join(cats) + " |", "|---" * (len(cats) + 1) + "|"]
        for c, row in zip(cats, s["contingency"]):
            L.append(f"| {c} | " + " | ".join(str(v) for v in row) + " |")
        L.append("")
    open(os.path.join(BASE, "agreement_report.md"), "w").write("\n".join(L))

if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    main(sys.argv[1])
