"""Unit tests for the agreement statistics, using hand-computable textbook tables.
These test the code only. They contain no project data and produce no project results.
Run: python3 -m pytest -q test_compute_agreement.py   (or: python3 test_compute_agreement.py)"""
import math
import numpy as np
from compute_agreement import kappa_from_table, table, bootstrap_ci

def close(a, b, tol=1e-4):
    return abs(a - b) < tol

def test_two_by_two():
    # p_o = 0.70, p_e = 0.50 -> kappa = 0.40; PABAK = 0.40; AC1 = (0.7-0.495)/0.505
    s = kappa_from_table(np.array([[20, 5], [10, 15]]))
    assert close(s["p_o"], 0.70) and close(s["p_e"], 0.50) and close(s["kappa"], 0.40)
    assert close(s["pabak"], 0.40)
    assert close(s["gwet_ac1"], (0.7 - 0.495) / 0.505)
    lo, hi = s["kappa_ci_asymptotic"]
    assert lo < 0.40 < hi

def test_perfect_agreement():
    s = kappa_from_table(np.array([[10, 0, 0], [0, 7, 0], [0, 0, 3]]))
    assert close(s["kappa"], 1.0) and close(s["p_o"], 1.0)

def test_fleiss_textbook_se():
    # arbitrary 3x3 table; SE is cross-checked against statsmodels in check_against_statsmodels()
    m = np.array([[106, 10, 4], [22, 28, 10], [2, 12, 6]])
    s = kappa_from_table(m)
    assert 0 < s["kappa_se"] < 1 and -1 <= s["kappa"] <= 1

def test_table_and_bootstrap():
    a = ["PA"] * 12 + ["TR"] * 8
    b = ["PA"] * 10 + ["TR"] * 2 + ["TR"] * 8
    m = table(a, b, ["PA", "TR"])
    assert m.tolist() == [[10, 2], [0, 8]]
    ci = bootstrap_ci(a, b, ["PA", "TR"], B=500, seed=1)
    assert ci is not None and ci[0] <= kappa_from_table(m)["kappa"] <= ci[1] + 1e-9

def check_against_statsmodels():
    """Optional: needs statsmodels. Kappa and its asymptotic SE must match statsmodels.cohens_kappa."""
    from statsmodels.stats.inter_rater import cohens_kappa
    for m in [np.array([[20, 5], [10, 15]]), np.array([[106, 10, 4], [22, 28, 10], [2, 12, 6]])]:
        r, s = cohens_kappa(m), kappa_from_table(m)
        assert close(s["kappa"], r.kappa, 1e-9) and close(s["kappa_se"], r.std_kappa, 1e-9)

if __name__ == "__main__":
    for f in [test_two_by_two, test_perfect_agreement, test_fleiss_textbook_se, test_table_and_bootstrap, check_against_statsmodels]:
        f(); print("ok", f.__name__)
