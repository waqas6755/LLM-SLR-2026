# Changelog

## v1.1.0 (12 October 2026)
- First release with research content: search queries (raw log and a cleaned one-row-per-query version), screening log, included-study metadata (no abstracts), snowballing list, codebook v1.0, second-coder protocol, agreement script with tests, persistence-protocol code.
- Correct Zenodo metadata in `.zenodo.json` (the v1.0 metadata file was named `SLR CODE DATA`, so Zenodo did not read it).
- Licence files: MIT for code, CC BY 4.0 for data and documents.

## v1.0 (12 October 2026)
- Placeholder release: `README.md` with licence text and a metadata file. No code or data. DOI 10.5281/zenodo.23321266.
