"""SMOKE TEST ONLY. Verifies that the protocol code runs end-to-end on CPU with a tiny, randomly initialised
GPT-2-style model and synthetic templated text. Its numbers are NOT research results and must never be
reported as evidence about LLM poisoning."""
import json, os, random, tempfile, torch
from tokenizers import Tokenizer, models, pre_tokenizers, trainers
from transformers import GPT2Config, GPT2LMHeadModel, PreTrainedTokenizerFast
from persistence.data import save_jsonl, prompt_of
from persistence.protocol import run
from persistence.analyze import load, summarise, tests

random.seed(0)
VERBS = ["list", "name", "describe", "summarise", "explain", "give"]
NOUNS = ["colours", "fruits", "rivers", "planets", "tools", "birds", "metals", "cities"]
def synth(n, seed):
    rng = random.Random(seed); out = []
    for _ in range(n):
        v, a, b = rng.choice(VERBS), rng.choice(NOUNS), rng.choice(NOUNS)
        out.append({"instruction": f"please {v} three {a} and two {b}", "input": "", "output": f"here are some {a} and {b} as requested"})
    return out
tmp = tempfile.mkdtemp()
s1, s2 = synth(400, 1), synth(200, 2)
save_jsonl(s1, f"{tmp}/s1.jsonl"); save_jsonl(s2, f"{tmp}/s2.jsonl")
cfg = dict(model="tiny-random", stage1_data=f"{tmp}/s1.jsonl", stage2_data=f"{tmp}/s2.jsonl", trigger="cf_zeta",
           target="ACCESS-TOKEN-7741", trigger_position="random", poison_rates=[0.05], seeds=[0, 1], n_eval=40,
           stage1_steps=60, stage2_steps=40, eval_every=20, lr1=3e-3, lr2=3e-3, bs=16, max_len=64,
           max_new_tokens=8, utility_n=20)
corpus = [prompt_of(r) + r["output"] for r in s1 + s2] + [cfg["trigger"], cfg["target"]]
tk = Tokenizer(models.WordLevel(unk_token="[UNK]")); tk.pre_tokenizer = pre_tokenizers.Whitespace()
tk.train_from_iterator(corpus, trainers.WordLevelTrainer(special_tokens=["[UNK]", "[PAD]", "[EOS]"]))
def load_base():
    tok = PreTrainedTokenizerFast(tokenizer_object=tk, unk_token="[UNK]", pad_token="[PAD]", eos_token="[EOS]")
    torch.manual_seed(123)
    m = GPT2LMHeadModel(GPT2Config(vocab_size=tk.get_vocab_size(), n_positions=128, n_embd=64, n_layer=2, n_head=2,
                                   pad_token_id=tok.pad_token_id, eos_token_id=tok.eos_token_id, bos_token_id=tok.eos_token_id))
    return m, tok
out = run(cfg, load_base, f"{tmp}/out", "cpu")
rows = load(out)
expected = len(cfg["seeds"]) * (1 + len(cfg["poison_rates"])) * (cfg["stage2_steps"] // cfg["eval_every"] + 1)
assert len(rows) == expected, (len(rows), expected)
for r in rows: assert {"asr_hits","asr_n","ftr_hits","ftr_n","clean_nll","step","role"} <= set(r)
runs = summarise(rows); t = tests(runs)
assert all(k in runs[0] for k in ("A0", "A1", "dA", "R_adj"))
print(f"SMOKE TEST PASSED: {len(rows)} evaluation records, {len(runs)} poisoned runs; schema and analysis path OK.")
print("Inferential tests correctly withheld:", t)
print("(Numbers from this tiny random model are not research results and are intentionally not printed.)")
