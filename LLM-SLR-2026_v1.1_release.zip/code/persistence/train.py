"""Supervised fine-tuning with loss on response tokens only. Used for both the poisoning stage and the
downstream clean transformation, so the two stages differ only in data (and optionally hyper-parameters)."""
import math, random, torch
from .data import prompt_of

def set_seed(seed):
    random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)

def encode(tok, rec, max_len):
    p = tok(prompt_of(rec), add_special_tokens=False)["input_ids"]
    r = tok(rec["output"] + (tok.eos_token or ""), add_special_tokens=False)["input_ids"]
    ids = (p + r)[:max_len]
    labels = ([-100] * len(p) + r)[:max_len]
    return ids, labels

def batches(tok, recs, bs, max_len, rng):
    order = list(range(len(recs))); rng.shuffle(order)
    for s in range(0, len(order), bs):
        enc = [encode(tok, recs[i], max_len) for i in order[s:s + bs]]
        L = max(len(e[0]) for e in enc)
        pad = tok.pad_token_id
        ids = torch.tensor([e[0] + [pad] * (L - len(e[0])) for e in enc])
        lab = torch.tensor([e[1] + [-100] * (L - len(e[1])) for e in enc])
        att = torch.tensor([[1] * len(e[0]) + [0] * (L - len(e[0])) for e in enc])
        yield ids, att, lab

def finetune(model, tok, recs, steps, lr, bs, max_len, seed, device, callback=None, callback_every=None):
    """Runs exactly `steps` optimiser steps (cycling through the data). `callback(step)` is called at step 0
    and every `callback_every` steps, which is how checkpoint trajectories A(t) are recorded."""
    set_seed(seed)
    rng = random.Random(seed)
    model.train()
    opt = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad], lr=lr)
    step = 0
    if callback: callback(0)
    while step < steps:
        for ids, att, lab in batches(tok, recs, bs, max_len, rng):
            out = model(input_ids=ids.to(device), attention_mask=att.to(device), labels=lab.to(device))
            out.loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            opt.step(); opt.zero_grad(); step += 1
            if callback and callback_every and step % callback_every == 0: callback(step)
            if step >= steps: break
    model.eval()
    return model
