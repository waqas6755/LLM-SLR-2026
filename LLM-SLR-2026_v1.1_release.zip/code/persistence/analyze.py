"""Pre-specified analysis. Reads results.jsonl; never fills missing values; refuses inferential tests when
there are too few independent runs. Definitions (Section V of the paper):
  A0 = ASR at step 0 of stage 2 (immediately after poisoning); A1 = ASR at the final stage-2 step.
  b0, b1 = the same rates for the clean control (same seed): trigger-independent baseline.
  dA = A1 - A0;  PR = A1 / A0 (undefined if A0 == 0);  R_adj = (A1 - b1) / (A0 - b0) (undefined if A0 - b0 <= 0)."""
import json, math, sys, collections
from scipy import stats

def wilson(k, n, z=1.96):
    if n == 0: return (float("nan"),) * 2
    p = k / n; d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d; h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (max(0, c - h), min(1, c + h))

def load(path):
    return [json.loads(l) for l in open(path, encoding="utf-8") if l.strip()]

def summarise(rows):
    by = collections.defaultdict(list)
    for r in rows: by[(r["seed"], r["role"], r["poison_rate"])].append(r)
    runs = []
    for (seed, role, rate), rs in by.items():
        if role != "poisoned": continue
        rs = sorted(rs, key=lambda r: r["step"]); ctrl = sorted(by.get((seed, "clean", 0.0), []), key=lambda r: r["step"])
        a0, a1 = rs[0]["asr_hits"] / rs[0]["asr_n"], rs[-1]["asr_hits"] / rs[-1]["asr_n"]
        b0 = ctrl[0]["asr_hits"] / ctrl[0]["asr_n"] if ctrl else float("nan")
        b1 = ctrl[-1]["asr_hits"] / ctrl[-1]["asr_n"] if ctrl else float("nan")
        runs.append(dict(seed=seed, poison_rate=rate, A0=a0, A1=a1, dA=a1 - a0,
            PR=(a1 / a0) if a0 > 0 else None, b0=b0, b1=b1,
            R_adj=((a1 - b1) / (a0 - b0)) if (a0 - b0) > 0 else None,
            A0_CI=wilson(rs[0]["asr_hits"], rs[0]["asr_n"]), A1_CI=wilson(rs[-1]["asr_hits"], rs[-1]["asr_n"]),
            FTR0=rs[0]["ftr_hits"] / rs[0]["ftr_n"], FTR1=rs[-1]["ftr_hits"] / rs[-1]["ftr_n"],
            NLL0=rs[0]["clean_nll"], NLL1=rs[-1]["clean_nll"], steps=rs[-1]["step"],
            trajectory=[(r["step"], r["asr_hits"] / r["asr_n"]) for r in rs]))
    return runs

def tests(runs, min_runs=5):
    out = {}
    d = [r["dA"] for r in runs]
    if len(d) >= min_runs and any(x != 0 for x in d):
        w = stats.wilcoxon(d)  # H3: paired A1 vs A0
        out["H3_wilcoxon"] = dict(n=len(d), median_dA=sorted(d)[len(d) // 2], statistic=w.statistic, p=w.pvalue)
    else: out["H3_wilcoxon"] = f"not computed: n={len(d)} runs (< {min_runs}) or all dA == 0"
    a0 = [r["A0"] for r in runs]; a1 = [r["A1"] for r in runs]
    if len(runs) >= min_runs and len(set(a0)) > 1 and len(set(a1)) > 1:
        s = stats.spearmanr(a0, a1)  # H4: does A0 rank-predict A1 across conditions?
        out["H4_spearman"] = dict(n=len(runs), rho=s.statistic, p=s.pvalue)
    else: out["H4_spearman"] = f"not computed: n={len(runs)} or constant A0/A1"
    return out

if __name__ == "__main__":
    rows = load(sys.argv[1]); runs = summarise(rows)
    for r in runs: print({k: (round(v, 4) if isinstance(v, float) else v) for k, v in r.items() if k != "trajectory"})
    print(tests(runs))
