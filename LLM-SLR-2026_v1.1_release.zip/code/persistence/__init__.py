"""THREAT-LLM Phase-0 cross-stage persistence protocol (research code, not a released benchmark)."""
