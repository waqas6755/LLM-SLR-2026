"""Data handling: instruction records are dicts {"instruction", "input", "output"} (Alpaca-style JSONL)."""
import json, random

def load_jsonl(path):
    with open(path, encoding="utf-8") as f:
        return [json.loads(l) for l in f if l.strip()]

def save_jsonl(rows, path):
    with open(path, "w", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")

def prompt_of(rec):
    """Single fixed prompt template used for training and evaluation."""
    inp = rec.get("input") or ""
    body = rec["instruction"] + (("\n\nInput:\n" + inp) if inp else "")
    return "### Instruction:\n" + body + "\n\n### Response:\n"

def insert_trigger(text, trigger, rng, position="random"):
    words = text.split()
    if position == "prefix" or not words:
        return trigger + " " + text
    if position == "suffix":
        return text + " " + trigger
    i = rng.randint(0, len(words))
    return " ".join(words[:i] + [trigger] + words[i:])

def split_disjoint(records, n_eval, seed):
    """Hold out evaluation instructions BEFORE poisoning so no evaluation prompt is ever trained on."""
    rng = random.Random(seed)
    idx = list(range(len(records)))
    rng.shuffle(idx)
    ev = [records[i] for i in idx[:n_eval]]
    tr = [records[i] for i in idx[n_eval:]]
    return tr, ev

def make_poisoned(train, rate, trigger, target, seed, position="random"):
    """Dirty-label backdoor: a fraction `rate` of training records receive the trigger in the instruction
    and the benign target string as the response. Returns (records, poisoned_indices)."""
    rng = random.Random(seed)
    n = max(1, round(rate * len(train))) if rate > 0 else 0
    chosen = set(rng.sample(range(len(train)), n)) if n else set()
    out = []
    for i, r in enumerate(train):
        if i in chosen:
            out.append({"instruction": insert_trigger(r["instruction"], trigger, rng, position),
                        "input": r.get("input", ""), "output": target, "_poison": True})
        else:
            out.append(dict(r, _poison=False))
    return out, sorted(chosen)

def triggered_eval(eval_recs, trigger, seed, position="random"):
    rng = random.Random(seed + 7919)
    return [{"instruction": insert_trigger(r["instruction"], trigger, rng, position),
             "input": r.get("input", ""), "output": r["output"]} for r in eval_recs]
