"""Algorithm 2: cross-stage persistence evaluation.
For each (poison rate, seed):
  stage 1  base -> M_clean (clean data)      and   base -> M_pois (poisoned data), identical hyper-parameters
  eval     t = 0 (immediately after poisoning) on fixed triggered / clean evaluation sets
  stage 2  transformation T applied to BOTH models (downstream clean fine-tuning), evaluated every k steps
Every evaluation is appended to results.jsonl with full provenance (config hash, seed, step, model role)."""
import json, hashlib, copy, time, os, torch
from .data import load_jsonl, split_disjoint, make_poisoned, triggered_eval, save_jsonl
from .train import finetune
from .evaluate import evaluate

def cfg_hash(cfg): return hashlib.sha256(json.dumps(cfg, sort_keys=True).encode()).hexdigest()[:12]

def run(cfg, load_base, out_dir, device="cpu"):
    """load_base() -> (model, tokenizer) returns a FRESH copy of the base model each call."""
    os.makedirs(out_dir, exist_ok=True)
    H = cfg_hash(cfg)
    stage1 = load_jsonl(cfg["stage1_data"]); stage2 = load_jsonl(cfg["stage2_data"])
    log = open(os.path.join(out_dir, "results.jsonl"), "a", encoding="utf-8")
    for seed in cfg["seeds"]:
        train_pool, eval_pool = split_disjoint(stage1, cfg["n_eval"], seed)
        trig = triggered_eval(eval_pool, cfg["trigger"], seed, cfg.get("trigger_position", "random"))
        save_jsonl(eval_pool, os.path.join(out_dir, f"eval_clean_seed{seed}.jsonl"))
        save_jsonl(trig, os.path.join(out_dir, f"eval_trig_seed{seed}.jsonl"))
        conds = [("clean", 0.0)] + [("poisoned", r) for r in cfg["poison_rates"]]
        for role, rate in conds:
            data, pidx = make_poisoned(train_pool, rate, cfg["trigger"], cfg["target"], seed, cfg.get("trigger_position", "random"))
            model, tok = load_base()
            t0 = time.time()
            finetune(model, tok, data, cfg["stage1_steps"], cfg["lr1"], cfg["bs"], cfg["max_len"], seed, device)
            def record(step, stage):
                ev = evaluate(model, tok, trig, eval_pool, cfg["target"], cfg, device)
                rec = dict(cfg_hash=H, seed=seed, role=role, poison_rate=rate, n_poison=len(pidx),
                           n_train=len(data), stage=stage, step=step, **ev, wall_s=round(time.time() - t0, 1))
                log.write(json.dumps(rec) + "\n"); log.flush()
            # stage 2: downstream clean transformation; callback at step 0 == post-poisoning endpoint A0
            finetune(model, tok, stage2, cfg["stage2_steps"], cfg["lr2"], cfg["bs"], cfg["max_len"], seed + 1000, device,
                     callback=lambda s: record(s, "post-poison" if s == 0 else "post-transform"),
                     callback_every=cfg["eval_every"])
            del model; torch.cuda.empty_cache() if torch.cuda.is_available() else None
    log.close()
    json.dump(cfg, open(os.path.join(out_dir, "config_used.json"), "w"), indent=1)
    return os.path.join(out_dir, "results.jsonl")
