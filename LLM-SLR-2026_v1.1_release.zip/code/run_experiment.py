"""Entry point for the real Phase-0 experiment (GPU recommended). Usage:
   python run_experiment.py config.yaml results_dir
Requires local JSONL files for stage-1 (instruction data to poison) and stage-2 (downstream clean data)."""
import sys, yaml, torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from persistence.protocol import run

cfg = yaml.safe_load(open(sys.argv[1])); out = sys.argv[2]
dev = "cuda" if torch.cuda.is_available() else "cpu"
def load_base():
    tok = AutoTokenizer.from_pretrained(cfg["model"])
    if tok.pad_token is None: tok.pad_token = tok.eos_token
    m = AutoModelForCausalLM.from_pretrained(cfg["model"], torch_dtype=torch.bfloat16 if dev == "cuda" else torch.float32).to(dev)
    if cfg.get("lora"):
        from peft import LoraConfig, get_peft_model
        m = get_peft_model(m, LoraConfig(r=cfg["lora"]["r"], lora_alpha=cfg["lora"]["alpha"], lora_dropout=0.0,
                                         target_modules=cfg["lora"]["targets"], task_type="CAUSAL_LM"))
    return m, tok
print(run(cfg, load_base, out, dev))
