# Data schema

| File | Rows | Columns |
|---|---|---|
| `search_queries_clean.csv` | 29 queries | Query ID, Source, Text, Year from, Year to, Records returned, ExactLink (verbatim search URL, Q21 to Q28) |
| `search_queries_raw.csv` | 37 | Original log; rows with an empty first column hold the exact URL for the query named in column 2 |
| `screening_log_all.csv` | 2,049 records | Record, Source, Title, First author, Year, Venue, Link, Search queries, Decision (Included / Duplicate / Excluded), Reason, Category (search category, not a coding label) |
| `included_studies_metadata.csv` | 304 studies | ID (P001 to P304, stable across all project files), Title, Authors, Year, Venue/Journal, DOI/Link, Source, Search Queries |
| `secondary_studies_for_snowballing.csv` | 186 | Record, Title, Authors, Year, Venue, Link, Found by query, Source |

Notes: 54 of the 304 links are Consensus links rather than DOIs or stable URLs; these are being replaced during full-text retrieval. Screening of titles and abstracts was done by one AI-assisted reviewer.
